# Contributing

Anyone interested in contributing to the Argo CD operator is welcomes and 
should start by reviewing the [development][docs_dev] documentation.

[docs_dev]:./docs/contribute/development.md
